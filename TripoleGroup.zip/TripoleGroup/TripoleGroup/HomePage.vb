﻿Imports MySql.Data.MySqlClient

Public Class HomePage
    Dim connectionString As String = "Server=localhost;Database=it13db;Uid=root;Pwd=;"
    Dim connection As New MySqlConnection(connectionString)

    Private Sub btn_manageUsers_Click(sender As Object, e As EventArgs) Handles btn_manageUsers.Click
        ' Hide the current form
        Me.Hide()

        ' Create an instance of HomePage form and show it
        Dim Users As New Users()
        Users.Show()
    End Sub
End Class