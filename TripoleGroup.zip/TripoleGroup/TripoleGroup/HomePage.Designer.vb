﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HomePage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btn_manageUsers = New Button()
        SuspendLayout()
        ' 
        ' btn_manageUsers
        ' 
        btn_manageUsers.Location = New Point(322, 45)
        btn_manageUsers.Name = "btn_manageUsers"
        btn_manageUsers.Size = New Size(123, 43)
        btn_manageUsers.TabIndex = 0
        btn_manageUsers.Text = "Manage Users"
        btn_manageUsers.UseVisualStyleBackColor = True
        ' 
        ' HomePage
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btn_manageUsers)
        Name = "HomePage"
        Text = "Home Page"
        ResumeLayout(False)
    End Sub

    Friend WithEvents btn_manageUsers As Button
End Class
