﻿Imports MySql.Data.MySqlClient
Imports Mysqlx

Public Class LoginForm

    Dim connectionString As String = "Server=localhost;Database=it13db;Uid=root;Pwd=;"
    Dim connection As New MySqlConnection(connectionString)

    Dim login_email As String
    Dim login_password As String

    Private Sub btn_homepage_login_Click(sender As Object, e As EventArgs) Handles btn_homepage_login.Click
        ' Get the user email and password from the textboxes
        Dim login_email As String = txtbox_loginpage_email.Text
        Dim login_password As String = txtbox_loginpage_password.Text

        ' Check if the input fields are not empty
        If String.IsNullOrEmpty(login_email) OrElse String.IsNullOrEmpty(login_password) Then
            MessageBox.Show("Please enter both email and password.")
            Return
        End If

        ' Try to connect to the database and validate the user
        Try
            ' Open the database connection
            connection.Open()

            ' SQL query to check the credentials in the users table
            Dim query As String = "SELECT * FROM users WHERE user_email = @user_email AND user_password = @user_password"

            ' Create a MySQL command
            Dim cmd As New MySqlCommand(query, connection)
            cmd.Parameters.AddWithValue("@user_email", login_email)
            cmd.Parameters.AddWithValue("@user_password", login_password)

            ' Execute the query and get the result
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            ' Check if a user is found
            If reader.HasRows Then
                ' User found, navigate to HomePage form
                MessageBox.Show("Login Success!")

                ' Hide the current login form
                Me.Hide()

                ' Create an instance of HomePage form and show it
                Dim homePage As New HomePage()
                homePage.Show()

                ' Optionally, you can close the login form after opening the HomePage
                ' Me.Close()  ' This will close the login form
            Else
                MessageBox.Show("Invalid email or password.")
            End If

            ' Close the reader and connection
            reader.Close()
            connection.Close()

        Catch ex As MySqlException
            ' Handle any MySQL connection errors
            MessageBox.Show("Error connecting to the database: " & ex.Message)
        End Try
    End Sub

End Class
