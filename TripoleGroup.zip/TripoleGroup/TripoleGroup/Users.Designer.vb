﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Users
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btn_users_create = New Button()
        btn_users_update = New Button()
        btn_users_delete = New Button()
        table_users = New DataGridView()
        TextBox1 = New TextBox()
        btn_users_search = New Button()
        user_id = New DataGridViewTextBoxColumn()
        user_first_name = New DataGridViewTextBoxColumn()
        user_last_name = New DataGridViewTextBoxColumn()
        user_email = New DataGridViewTextBoxColumn()
        user_active = New DataGridViewTextBoxColumn()
        CType(table_users, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btn_users_create
        ' 
        btn_users_create.Location = New Point(62, 115)
        btn_users_create.Name = "btn_users_create"
        btn_users_create.Size = New Size(112, 34)
        btn_users_create.TabIndex = 0
        btn_users_create.Text = "Create New User"
        btn_users_create.UseVisualStyleBackColor = True
        ' 
        ' btn_users_update
        ' 
        btn_users_update.Location = New Point(62, 184)
        btn_users_update.Name = "btn_users_update"
        btn_users_update.Size = New Size(112, 34)
        btn_users_update.TabIndex = 1
        btn_users_update.Text = "Update "
        btn_users_update.UseVisualStyleBackColor = True
        ' 
        ' btn_users_delete
        ' 
        btn_users_delete.Location = New Point(62, 251)
        btn_users_delete.Name = "btn_users_delete"
        btn_users_delete.Size = New Size(112, 34)
        btn_users_delete.TabIndex = 2
        btn_users_delete.Text = "Delete"
        btn_users_delete.UseVisualStyleBackColor = True
        ' 
        ' table_users
        ' 
        table_users.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        table_users.Columns.AddRange(New DataGridViewColumn() {user_id, user_first_name, user_last_name, user_email, user_active})
        table_users.Location = New Point(275, 115)
        table_users.Name = "table_users"
        table_users.Size = New Size(513, 228)
        table_users.TabIndex = 3
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(362, 35)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(236, 23)
        TextBox1.TabIndex = 4
        ' 
        ' btn_users_search
        ' 
        btn_users_search.Location = New Point(646, 34)
        btn_users_search.Name = "btn_users_search"
        btn_users_search.Size = New Size(75, 23)
        btn_users_search.TabIndex = 5
        btn_users_search.Text = "Search"
        btn_users_search.UseVisualStyleBackColor = True
        ' 
        ' user_id
        ' 
        user_id.HeaderText = "ID"
        user_id.Name = "user_id"
        ' 
        ' user_first_name
        ' 
        user_first_name.HeaderText = "First Name"
        user_first_name.Name = "user_first_name"
        ' 
        ' user_last_name
        ' 
        user_last_name.HeaderText = "Last Name"
        user_last_name.Name = "user_last_name"
        ' 
        ' user_email
        ' 
        user_email.HeaderText = "Email"
        user_email.Name = "user_email"
        ' 
        ' user_active
        ' 
        user_active.HeaderText = "Active"
        user_active.Name = "user_active"
        ' 
        ' Users
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btn_users_search)
        Controls.Add(TextBox1)
        Controls.Add(table_users)
        Controls.Add(btn_users_delete)
        Controls.Add(btn_users_update)
        Controls.Add(btn_users_create)
        Name = "Users"
        Text = "Manage Users"
        CType(table_users, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btn_users_create As Button
    Friend WithEvents btn_users_update As Button
    Friend WithEvents btn_users_delete As Button
    Friend WithEvents table_users As DataGridView
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents btn_users_search As Button
    Friend WithEvents user_id As DataGridViewTextBoxColumn
    Friend WithEvents user_first_name As DataGridViewTextBoxColumn
    Friend WithEvents user_last_name As DataGridViewTextBoxColumn
    Friend WithEvents user_email As DataGridViewTextBoxColumn
    Friend WithEvents user_active As DataGridViewTextBoxColumn
End Class
