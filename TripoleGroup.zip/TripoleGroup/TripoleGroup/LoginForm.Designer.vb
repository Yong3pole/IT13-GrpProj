﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LoginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txt_loginpage_email = New Label()
        txtbox_loginpage_email = New TextBox()
        txtbox_loginpage_password = New TextBox()
        txt_loginpage_Password = New Label()
        txt_loginpage_welcome = New Label()
        btn_homepage_login = New Button()
        SuspendLayout()
        ' 
        ' txt_loginpage_email
        ' 
        txt_loginpage_email.AutoSize = True
        txt_loginpage_email.Location = New Point(128, 125)
        txt_loginpage_email.Name = "txt_loginpage_email"
        txt_loginpage_email.Size = New Size(36, 15)
        txt_loginpage_email.TabIndex = 0
        txt_loginpage_email.Text = "Email"
        ' 
        ' txtbox_loginpage_email
        ' 
        txtbox_loginpage_email.Location = New Point(211, 122)
        txtbox_loginpage_email.Name = "txtbox_loginpage_email"
        txtbox_loginpage_email.Size = New Size(176, 23)
        txtbox_loginpage_email.TabIndex = 2
        ' 
        ' txtbox_loginpage_password
        ' 
        txtbox_loginpage_password.Location = New Point(211, 179)
        txtbox_loginpage_password.Name = "txtbox_loginpage_password"
        txtbox_loginpage_password.Size = New Size(176, 23)
        txtbox_loginpage_password.TabIndex = 3
        ' 
        ' txt_loginpage_Password
        ' 
        txt_loginpage_Password.AutoSize = True
        txt_loginpage_Password.Location = New Point(128, 187)
        txt_loginpage_Password.Name = "txt_loginpage_Password"
        txt_loginpage_Password.Size = New Size(57, 15)
        txt_loginpage_Password.TabIndex = 4
        txt_loginpage_Password.Text = "Password"
        ' 
        ' txt_loginpage_welcome
        ' 
        txt_loginpage_welcome.AutoSize = True
        txt_loginpage_welcome.Location = New Point(230, 44)
        txt_loginpage_welcome.Name = "txt_loginpage_welcome"
        txt_loginpage_welcome.Size = New Size(73, 15)
        txt_loginpage_welcome.TabIndex = 5
        txt_loginpage_welcome.Text = "LOGIN PAGE"
        ' 
        ' btn_homepage_login
        ' 
        btn_homepage_login.Location = New Point(230, 253)
        btn_homepage_login.Name = "btn_homepage_login"
        btn_homepage_login.Size = New Size(75, 23)
        btn_homepage_login.TabIndex = 6
        btn_homepage_login.Text = "LOGIN"
        btn_homepage_login.UseVisualStyleBackColor = True
        ' 
        ' LoginForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(545, 325)
        Controls.Add(btn_homepage_login)
        Controls.Add(txt_loginpage_welcome)
        Controls.Add(txt_loginpage_Password)
        Controls.Add(txtbox_loginpage_password)
        Controls.Add(txtbox_loginpage_email)
        Controls.Add(txt_loginpage_email)
        Name = "LoginForm"
        Text = "Login Page"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txt_loginpage_email As Label
    Friend WithEvents txtbox_loginpage_email As TextBox
    Friend WithEvents txtbox_loginpage_password As TextBox
    Friend WithEvents txt_loginpage_Password As Label
    Friend WithEvents txt_loginpage_welcome As Label
    Friend WithEvents btn_homepage_login As Button

End Class
