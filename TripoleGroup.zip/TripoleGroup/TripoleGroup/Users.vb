﻿Imports MySql.Data.MySqlClient

Public Class Users
    Dim connectionString As String = "Server=localhost;Database=it13db;Uid=root;Pwd=;"
    Dim connection As New MySqlConnection(connectionString)

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FillDataGridView()
    End Sub

    Private Sub FillDataGridView()
        ' Create a MySQL connection
        Using conn As New MySqlConnection(connectionString)
            ' Define the SQL query to retrieve data
            Dim query As String = "SELECT user_id, user_first_name, user_last_name, user_email, user_active FROM users"

            ' Create a MySQL DataAdapter to fill the DataTable
            Dim adapter As New MySqlDataAdapter(query, conn)
            Dim dt As New DataTable()

            Try
                ' Open the connection and fill the DataTable with the query result
                conn.Open()
                adapter.Fill(dt)

                ' Bind the DataTable to the DataGridView
                table_users.DataSource = dt

                ' Optional: Format the user_active column if you want to show "Active" / "Inactive" instead of 1 / 0
                FormatActiveColumn()

            Catch ex As Exception
                ' Handle any errors that occur
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub

    ' Optional: Format the 'user_active' column to display "Active" or "Inactive"
    Private Sub FormatActiveColumn()
        For Each row As DataGridViewRow In table_users.Rows
            If row.Cells("user_active").Value IsNot Nothing Then
                If row.Cells("user_active").Value.ToString() = "1" Then
                    row.Cells("user_active").Value = "Active"
                Else
                    row.Cells("user_active").Value = "Inactive"
                End If
            End If
        Next
    End Sub

End Class